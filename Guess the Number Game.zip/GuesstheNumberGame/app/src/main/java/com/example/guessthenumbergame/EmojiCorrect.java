package com.example.guessthenumbergame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class EmojiCorrect extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emoji_correct);
        View v = findViewById(R.id.play_button);
        v.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.play_button) {
            Intent i = new Intent(this, MainActivity.class);
            this.startActivity(i);
        }
        
    }
}
