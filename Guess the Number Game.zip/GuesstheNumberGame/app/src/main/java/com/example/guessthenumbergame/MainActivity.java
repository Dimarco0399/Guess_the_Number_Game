package com.example.guessthenumbergame;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;


import java.util.Random;

public class MainActivity extends AppCompatActivity {

    int temp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Random r = new Random();
        temp = r.nextInt(5) + 1;
    }

    public boolean checkEmpty(EditText foo) {
        if (foo.getText().toString().trim().length() == 0)
            return true;
        else
            return false;
    }

    public void displayMsg(String foo) {
        Toast.makeText(MainActivity.this, foo, Toast.LENGTH_SHORT).show();
    }

    public void checkGame(View v) {
        EditText foo = (EditText) findViewById(R.id.number_input);
        if (checkEmpty(foo) == true) {
            displayMsg("Guess a Number");
        } else {
            int boo = Integer.parseInt(foo.getText().toString());
            if (boo > temp) {
                displayMsg("Lower");
                Intent i = new Intent(this, EmojiAnswer.class);
                startActivity(i);
                finish();
            } else if (boo < temp) {
                displayMsg("Higher");
                Intent i = new Intent(this, EmojiAnswer.class);
                startActivity(i);
                finish();
            } else {
                displayMsg("Good Guess");
                Random r = new Random();
                temp = r.nextInt(5) + 1;
                Intent i = new Intent(this, EmojiCorrect.class);
                startActivity(i);
                finish();

            }
        }
    }

}